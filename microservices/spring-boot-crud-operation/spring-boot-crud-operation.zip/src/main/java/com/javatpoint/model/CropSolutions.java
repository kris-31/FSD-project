package com.javatpoint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//mark class as an Entity   
@Entity
//
@Getter @Setter
public class CropSolutions {
//Defining book id as primary key  
	@Id
	  private long productId;
	
	 private String productName;
	
	  private String productType;
	  private String productDescription;
	  private String productQuantity;
	  private String productLastUpdated;
	
	  private int productPrice;

	

	

	
}
